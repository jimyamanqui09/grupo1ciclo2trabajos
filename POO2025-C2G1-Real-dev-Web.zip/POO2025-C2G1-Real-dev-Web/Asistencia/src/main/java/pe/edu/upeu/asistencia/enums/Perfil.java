package pe.edu.upeu.asistencia.enums;

public enum Perfil {
    ADMIN,
    DOCENTE,
    ALUMNO
}