package pe.edu.upeu.asistencia.enums;

public enum TipoEvento {
    CONFERENCIA,
    TALLER,
    SEMINARIO
}